package AJones.Zoo;

public class Bear extends Animal {
// Keeps track of number of Bear objects
    private static int numOfBear = 0;

// Constructor
    public Bear(String sex, String weight, int age, String name, String animalID,
                 String animalBirthDate, String animalColor, String animalLocation, String animalState) {
        super(sex,"", weight, age, name, animalID, animalBirthDate, animalColor, animalLocation, animalState);
        numOfBear++;
    }

// Getter for numOfBear
    public static int getNumOfBear() {return numOfBear;}
}
