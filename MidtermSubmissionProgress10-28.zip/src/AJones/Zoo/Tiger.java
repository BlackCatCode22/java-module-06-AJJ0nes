package AJones.Zoo;

public class Tiger extends Animal {
// Keeps track of number of Tiger objects
    private static int numOfTiger = 0;

// Constructor
    public Tiger(String sex, String weight, int age, String name, String animalID,
                 String animalBirthDate, String animalColor, String animalLocation, String animalState) {
        super(sex,"", weight, age, name, animalID, animalBirthDate, animalColor, animalLocation, animalState);
        numOfTiger++;
    }

// Getter for numOfTiger
    public static int getNumOfTiger() {return numOfTiger;}
}
