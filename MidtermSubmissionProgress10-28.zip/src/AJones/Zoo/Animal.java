package AJones.Zoo;

public class Animal {

//keeps track of animals
    public static int NumOfAnimals;

// creates the attributes of the animal
    private String sex;
    private String species;
    private String weight;
    private int age;//Maybe unnecessary
    private String animalName;
    private String animalID;
    private String animalBirthDate;
    private String animalColor;
    private String animalLocation;
    private String animalState;
    private String animalArrivalDate;

//this is a constructor must have same name ass class/have no return type/and is public
//initialize the object when created //allows creation and initialization in one command
    public Animal(String sex, String species, String weight, int age, String name, String animalID,
                  String animalBirthDate, String animalColor, String animalLocation, String animalState){
        NumOfAnimals++;//increments the counter
        this.species = species;
        this.sex = sex;
        this.weight = weight;
        this.age = age;
        this.animalName = name;
        this.animalID = animalID;
        this.animalBirthDate = animalBirthDate;
        this.animalColor = animalColor;
        this.animalLocation = animalLocation;
        this.animalState = animalState;

    }

    public Animal(String sex, String species, int age, String name, String extraInfo, String color, String location, String state) {
    }


    // Getter and Setter for sex
    public String getSex() {
        return sex;
    }
    public void setSex(String sex) {
        this.sex = sex;
    }

// Getter and Setter for weight
    public String getWeight() {
        return weight;
    }
    public void setWeight(String weight) {
        this.weight = weight;
    }

// Getter and Setter for age //todo may be unnecessary
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

// Getter and Setter for animalName
    public String getAnimalName() {
        return animalName;
    }
    public void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

// Getter and Setter for animalID
    public String getAnimalID() {
        return animalID;
    }
    public void setAnimalID(String animalID) {
        this.animalID = animalID;
    }

// Getter and Setter for animalBirthDate
    public String getAnimalBirthDate() {
        return animalBirthDate;
    }
    public void setAnimalBirthDate(String animalBirthDate) {
        this.animalBirthDate = animalBirthDate;
    }

// Getter and Setter for animalColor
    public String getAnimalColor() {
        return animalColor;
    }
    public void setAnimalColor(String animalColor) {
        this.animalColor = animalColor;
    }

// Getter and Setter for animalLocation
    public String getAnimalLocation() {
        return animalLocation;
    }
    public void setAnimalLocation(String animalOrigin) {
        this.animalLocation = animalLocation;
    }

// Getter and Setter for animalState
    public String getAnimalState() {
        return animalState;
    }
    public void setAnimalState(String animalState) {
        this.animalLocation = animalState;
    }

// Getter and Setter for animalArrivalDate
    public String getAnimalArrivalDate() {
        return animalArrivalDate;
    }
    public void setAnimalArrivalDate(String animalArrivalDate) {
        this.animalArrivalDate = animalArrivalDate;
    }

// Getter and setter for species
    public String getSpecies() {return species;}
    public void setSpecies(String species) {this.species = species;}

    public static int getNumOfAnimals() {return NumOfAnimals;}


// creates a function to call. creates a shortcut for printing all the elements. //todo debug command
    public String toString() {
        return  "Sex='" + sex + '\'' +
                ", Weight=" + weight +
                ", Age=" + age +
                ", Name='" + animalName + '\'' +
                ", ID='" + animalID + '\'' +
                ", Birth Year='" + animalBirthDate + '\'' +
                ", Color='" + animalColor + '\'' +
                ", Location='" + animalLocation + '\'' +
                ", State='" + animalState + '\'' +
                ", Arrival Date='" + animalArrivalDate +
                ", species='" + species;
    }


}