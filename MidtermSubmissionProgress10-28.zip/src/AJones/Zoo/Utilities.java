package AJones.Zoo;


import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class Utilities {


    public static String arrivalDate() {
        Date today = new Date();
        //date format
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat formatterYear = new SimpleDateFormat("yyyy");

        // Format the date / store it
        String TodayDate = formatter.format(today);
        String TodayYear = formatterYear.format(today);

        // Return the date as a string
        return TodayDate;
    }




}

