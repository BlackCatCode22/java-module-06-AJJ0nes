package AJones.Zoo;

//MidTermSubmission
//AJones 10-2

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;


public class App {
    public static void main(String[] args) {


//todo hashmaps to stored the objects so there accessible
        HashMap<String, Hyena> HyenaMap = new HashMap<>();
        HashMap<String, Lion> LionMap = new HashMap<>();
        HashMap<String, Tiger> TigerMap = new HashMap<>();
        HashMap<String, Bear> BearMap = new HashMap<>();



        // Creates a variable containing the filepath of arriving animals
        File InputFile = new File("arrivingAnimals.txt");
        // create a new Buffered reader
        try (BufferedReader reader = new BufferedReader(new FileReader(InputFile))) {
            //creates a placeholder for each line
            String line;


            // Reads line by line
            while ((line = reader.readLine()) != null) {
                // print each line read
                //System.out.println(line); //todo debug line prints each line of txt file
                // splits each line by coma and space
                String[] ElementsOfInput = line.split(", ");

/*              //todo debug command - a foreach loop to print out each element of the line
                // placeholder for the current line number
                int elementNum = 0;
                // loop goes through element of the array ElementsOfInput temporally assigning each part to thePart
                for (String thePart : ElementsOfInput) {
                    System.out.println("Element " + elementNum + " of ElementsOfInput is: " + thePart);
                    elementNum++;//iterates the element number
                }
*/

            // creating a variable for each field of object and initializing those variables
                String sex;
                String species;
                String BirthSeason;
                String animalArrivalDate;
                String weight;              weight = ElementsOfInput[3];
                String animalColor;         animalColor = ElementsOfInput[2];
                String location;            location = ElementsOfInput[4];
                String state; state =       ElementsOfInput[5];

            // outputs variables that we don't need to split anymore
                //System.out.println("Weight: "+ weight);
                //System.out.println("Color: "+animalColor);
                //System.out.println("Location: "+location);
                //System.out.println("State: "+state);

            // splits element 0
                String[] SplitElement0 = ElementsOfInput[0].split(" ");
                int age = Integer.parseInt(SplitElement0[0]);
                sex = SplitElement0[3];
                species = SplitElement0[4];

            // outputs variables that we split from element 0
                //System.out.println("Age: "+ age);
                //System.out.println("sex: " + sex);
                //System.out.println("species: " + species);


            // splits element 1
                String[] SplitElement1 = ElementsOfInput[1].split(" ");
                BirthSeason = SplitElement1[2];

                // outputs variables that we split from element 1
                //System.out.println("Birth Season: "+ BirthSeason);


            //todo Create an object for each line

                String myName;

            //todo Hyena
                if (species.equals("hyena")) {
                    Hyena hyena = new Hyena(sex, species, age,
                            "", "Hy0" + Hyena.getNumOfHyena(), "", animalColor, location, state);
                        hyena.setSpecies(species);
                        hyena.setAnimalArrivalDate(Utilities.arrivalDate());
                        hyena.setAnimalName("");
                        hyena.setWeight(weight);

                    HyenaMap.put(hyena.getAnimalID(), hyena);//add the object to the hashmap using their unique id as a key

                    //System.out.println(hyena);// todo debug command
                }


            //todo Tiger
                if(species.equals("tiger")) {
                    Tiger tiger = new Tiger(sex, species, age,
                            "", "Ti0" + Tiger.getNumOfTiger(), "", animalColor, location, state);
                    tiger.setSpecies(species);
                    tiger.setAnimalArrivalDate(Utilities.arrivalDate());
                    tiger.setWeight(weight);

                   TigerMap.put(tiger.getAnimalID(), tiger);//add the object to the hashmap using their unique id as a key

                    //System.out.println(tiger);// todo debug command
                }


            //todo Bear
                if(species.equals("bear")) {
                    Bear bear = new Bear(sex, species, age,
                            "", "Be0" + Bear.getNumOfBear(), "", animalColor, location, state);
                    bear.setSpecies(species);
                    bear.setAnimalArrivalDate(Utilities.arrivalDate());
                    bear.setWeight(weight);

                    BearMap.put(bear.getAnimalID(), bear);//add the object to the hashmap using their unique id as a key

                    //System.out.println(bear);// todo debug command
                }


            //todo Lion
                if(species.equals("lion")) {
                    Lion lion = new Lion(sex, species, age,
                            "", "Li0" + Lion.getNumOfLion(), "", animalColor, location, state);
                    lion.setSpecies(species);
                    lion.setAnimalArrivalDate(Utilities.arrivalDate());
                    lion.setWeight(weight);

                    LionMap.put(lion.getAnimalID(), lion);//add the object to the hashmap using their unique id as a key

                    //System.out.println(lion);// todo debug command
                }




            }
        } catch (IOException e) {
            // Catch and print file errors
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }




        
//todo Make a user database access system
        Scanner scanner = new Scanner(System.in);
        int a = -1;
    // Ask the user for Animal ID
        System.out.println("Animal ID Options: " +
                "\n" + "Hy0 + Index # for Hyenas " + " count: "+ Hyena.getNumOfHyena() +
                "\n" + "Ti0 + Index # for Tigers " + " count: "+ Tiger.getNumOfTiger() +
                "\n" + "Li0 + Index # for Lions " + " count: "+ Lion.getNumOfLion() +
                "\n" + "Be0 + Index # for Bears " + " count: "+ Bear.getNumOfBear() +
                "\n");
        System.out.print("Enter Animal ID: " + "\n");
        String animalID = scanner.nextLine().trim(); // trims spaces

    // Check if ID belongs to a Hyena
        if (animalID.contains("Hy")) {
            String result = String.valueOf(HyenaMap.get(animalID));

            if (result != null) {
                System.out.println("Animal found: " + result);
            } else {
                System.out.println("No record found for ID: " + animalID);
            }
        }

    // Check if ID belongs to a Lion
        if (animalID.contains("Li")) {
            String result = String.valueOf(LionMap.get(animalID));

            if (result != null) {
                System.out.println("Animal found: " + result);
            } else {
                System.out.println("No record found for ID: " + animalID);
            }
        }

    // Check if ID belongs to a Tiger
        if (animalID.contains("Ti")) {
            String result = String.valueOf(TigerMap.get(animalID));

            if (result != null) {
                System.out.println("Animal found: " + result);
            } else {
                System.out.println("No record found for ID: " + animalID);
            }
        }

    // Check if ID belongs to a Bear
        if (animalID.contains("Be")) {
            String result = String.valueOf(BearMap.get(animalID));

            if (result != null) {
                System.out.println("Animal found: " + result);
            } else {
                System.out.println("No record found for ID: " + animalID);
            }
        }
        scanner.close();





    }
 }

