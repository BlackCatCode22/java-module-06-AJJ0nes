package AJones.Zoo;

public class Hyena extends Animal {
    // Keeps track of number of Hyena objects
    private static int numOfHyena = 0;

    // Constructor
    public Hyena(String sex, String weight, int age, String name, String animalID,
                 String animalBirthDate, String animalColor, String animalLocation, String animalState) {
        super(sex,"", weight, age, name, animalID, animalBirthDate, animalColor, animalLocation, animalState);
        numOfHyena++;

    }

    // Getter for numOfHyena
    public static int getNumOfHyena() {return numOfHyena;}



}
