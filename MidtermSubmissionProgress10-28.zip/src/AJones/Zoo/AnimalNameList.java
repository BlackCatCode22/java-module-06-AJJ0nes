package AJones.Zoo;

import java.util.ArrayList;

public class AnimalNameList {
    private ArrayList<String> hyenaNames;
    private ArrayList<String> lionNames;
    private ArrayList<String> tigerNames;
    private ArrayList<String> bearNames;

// Constructor to initialize the ArrayLists


    public AnimalNameList(ArrayList<String> hyenaNameList, ArrayList<String> lionNameList,
                          ArrayList<String> tigerNameList, ArrayList<String> bearNameList) {
        this.hyenaNames = new ArrayList<>();
        this.lionNames = new ArrayList<>();
        this.tigerNames = new ArrayList<>();
        this.bearNames = new ArrayList<>();
    }

//getters for each list
    public ArrayList<String> getHyenaNames() {return hyenaNames;}
    public ArrayList<String> getLionNames() {return lionNames;}
    public ArrayList<String> getTigerNames() {return tigerNames;}
    public ArrayList<String> getBearNames() {return bearNames;}

}


