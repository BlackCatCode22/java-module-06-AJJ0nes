package AJones.Zoo;

public class Lion extends Animal {
// Keeps track of number of Lion objects
    private static int numOfLion = 0;

// Constructor
    public Lion(String sex, String weight, int age, String name, String animalID,
                String animalBirthDate, String animalColor, String animalLocation, String animalState) {
        super(sex, "",weight, age, name, animalID, animalBirthDate, animalColor, animalLocation, animalState);
        numOfLion++;
    }

// Getter for numOfLion
    public static int getNumOfLion() {return numOfLion;}
}
